"""
myHashmap.py
Jonah Yabut
Implementing Hashmap 
"""

class MyHashMap:
    def __init__(self, load_factor=0.75,
                       initial_capacity=16):
        self.load_factor = load_factor 
        self.capacity = initial_capacity 
        self.size = 0
        self.buckets = [[] for _ in range(self.capacity)]

    """
    Resizes the self.buckets array when the load_factor is reached. """
    def resize(self):
        # Double the number of buckets
        self.capacity *= 2 
        # Create a new set of buckets that's twice as big as the old one
        new_buckets = [[] for _ in range(self.capacity)]
        # Add each key, value pair already in the MyHashMap to the new buckets
        for bucket in self.buckets:
            if bucket != []:
                for entry in bucket:
                    self.put(entry.getKey(), entry.getValue())
        # Update the self.buckets attribute with the new entries
        self.buckets = [[]for _ in range(self.capacity)]

    """
    Adds the specified key, value pair to the MyHashMap if 
    the key is not already in the MyHashMap. If adding a new key would
    surpass the load_factor, resize the MyHashMap before adding the key.
    Return true if successfully added to the MyHashMap.
    Raise an exception if the key is None. """
    def put(self, key, value):
        keyHash = hash(key)
        # TODO: write your put implementation here
        keyHash = hash(key)%self.capacity 
        #To return index to store value

        newEntry = self.MyHashMapEntry(key, value)
        if keyHash == None:
            raise Exception ("key equals none")
        #Hash exception for checking list
        elif keyHash >=0 and keyHash < self.capacity:    
            #else if statment for no index in list
            if self.size > self.load_factor*self.capacity: 
               #if statement for load> capacity
               self.resize()     
               #doubles capacity
            self.size += 2
            #increaseing size by 2
            self.buckets[keyHash].append(newEntry)
            return True
        pass 

    """
    Replaces the value that maps to the given key if it is present.
    Input: key is the key whose mapped value is being replaced.
           newValue is the value to replace the existing value with.
    Return true if the key was in this MyHashMap and replaced successfully.
    Raise an exception if the key is None. """
    def replace(self, key, newValue):
        # TODO: write your replace implementation here
        keyHash = hash(key)%self.capacity  
           #returns index

        if keyHash == None:
           raise Exception ("key equals none")
        #exception
        for bucket in self.buckets:
           #check through the Hashmap
           for entry in bucket:
               if entry.getKey() == key:
                    if entry.getValue() != [] and entry.getKey() == key: 
                     #if statement checking for value
                     entry.setValue(newValue) 
                 #new value >replace
           return True
       
        
        
        pass

    """
    Remove the entry corresponding to the given key.
    Return true if an entry for the given key was removed.
    Raise an exception if the key is None. """
    def remove(self, key):
        # TODO: write your remove implementation here
        pass 

    """
    Adds the key, value pair to the MyHashMap if it is not present.
    Otherwise, replace the existing value for that key with the given value.
    Raise an exception if the key is None. """
    def set(self, key, value):
        # TODO: Write your set implementation here
        keyHash = hash(key)%self.capacity
        if keyHash== None:
            raise Exception ("key equals none")
        else:
           for bucket in self.buckets:
               for entry in bucket:
                   if entry.getKey() == key:
                       #if dtatement if value is at index
                       entry=None
                       #remove entry 
        pass 


    """
    Return the value of the specified key. If the key is not in the
    MyHashMap, return None.
    Raise an exception if the key is None. """
    def get(self, key):
        # TODO: Write your get implementation here 
         keyHash = hash(key)%self.capacity     
         #returnindex
         if key == None:
           raise Exception ("key equals none")
         for bucket in self.buckets:
           for entry in bucket:
               if entry.getKey() == key: 
                   return entry.getValue()
               #get value from key check for match
              
    
         return None
    pass 

    """
    Return the number of key, value pairs in this MyHashMap. """
    def size(self):
        # TODO: Write your size implementation here 
       count = 0 
       #start 0
       for bucket in self.buckets:
           for entry in bucket:
               if entry.getValue() != [] and entry.getKey() != []:
                   #if statement for key and value at entry
                   count += 1
                   #increase by 1

       return count
       pass 

    """
    Return true if the MyHashMap contains no elements, and 
    false otherwise. """
    def isEmpty(self):
        # TODO: Write your isEmpty implementation here
        #if empty statment for if size =0
        if self.size ==0:
            #if empty
            return True
        else:
            return False
        
        
        
        
        pass 

    """
    Return true if the specified key is in this MyHashMap. 
    Raise an exception if the key is None. """
    def containsKey(self, key):
        # TODO: Write your containsKey implementation here 
        keyHash = hash(key)%self.capacity    
        if keyHash == None:
           raise Exception ("key equals none")
        for bucket in self.buckets: 
           for entry in bucket:
               if entry.getKey() == key:
                   #if statement if entry has desired key return true
                   return True
        pass 

    """
    Return a list containing the keys of this MyHashMap. 
    If it is empty, return an empty list. """
    def keys(self):
        # TODO: Write your keys implementation here
        pass 
   
        klist = []
        for bucket in self.buckets: 
           for entry in bucket:
               if entry.getKey() != []:
                   addkey = entry.getKey()
                   #add key if exist to list
                   klist.append(addkey)
                   return klist
               pass
           
    def __str__(self):
       ret_str = " "
       for bucket in self.buckets:
           #entry
           for entry in bucket:
               ret_str += str(entry)
           ret_str += "\n"
           #return if 
       return ret_str
    
class MyHashMapEntry:
        def __init__(self, key, value):
            self.key = key 
            self.value = value 

        def getKey(self):
            return self.key 
        
        def getValue(self):
            return self.value 
        
        def setValue(self, new_value):
            self.value = new_value 
      
        def __str__(self):
           return "({}, {})".format(self.key,self.value)   

if __name__ == "__main__":
   newmap = MyHashMap()
   newmap.put(0,4)
   newmap.put(1,2)
   newmap.put(2,5)
   #newmap.remove(0)
   print(newmap)
   print(newmap.keys())
   pass
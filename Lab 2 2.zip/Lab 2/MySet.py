class MySet:
    def __init__(self, initial_values):
        #initialize values from list
        self.__s = list(set(initial_values))
        #Set list for values
        self.__size = len(self.__s)
        #__size for number of elements in set

        def size(self):
            return self.__s
        # return statment for returning size/number of elements in set
        def values(self):
            return self.__s
        # return statment for return elements
        def search(self, value):
            return self.__s
            #return statment, exists in set return true if else false
        def insert(self, value):
         if value not in self.__s:
            self.__s.append(value)
            #add value to set
            self.__size += 1

        def delete(self,value):
           if value in self.__s:
            #if value exists delete
            self.__s.remove(value)
            #remove value from set
            self.__size -= 1
            return True
        return False
        
        def traverse(self):
          for value in self.__s:
            print(value)
            #print all values in set



        

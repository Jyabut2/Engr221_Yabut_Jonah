"""
Jonah Yabut 
doublyLinkedList class
implementation of doubly linked list
"""

from node import Node
from .doubleNode import DoubleNode 

class DoublyLinkedList():

    def __init__(self):
        self.__firstNode = None
        self.__lastNode = None 

    def isEmpty(self) -> bool:
        return self.getFirstNode() == None
    #check if empty by getting first node

    def first(self):
        # Raise an exception if the list is empty
        if self.isEmpty():
            raise Exception("Error: List is empty, cannot return first  value")
        return self.getFirstNode().getValue()

    # Return the first node in the list
    def getFirstNode(self) -> Node:
        return self.__firstNode

    def getLastNode(self):
        return self.__lastNode
    
    def setFirstNode(self, node):
        if isinstance(node, DoubleNode) or node is None:
            if node != None and type(node) != Node:
             raise Exception("Error: Input must be valid Node or None")
        else:
            self.__firstNode = node 

    def setLastNode(self, node):
        if isinstance(node, DoubleNode) or node is None:
            if node != None and type(node) != Node:
             raise Exception("Error: Input must be valid Node or None")
        else:
            self.__lastNode = node

    def find(self, value) -> Node:
        node = self.getFirstNode()
        while node != None:
            # If this node has the given value, return it
            if node.getValue() == value:
                return node 
            # Otherwise, grab the next node to check
            node = node.getNextNode()
        # If the value was not found, return None
        return None

    def insertFront(self, value,next,previous):
        new_node = DoubleNode(value)
        self.__value = value
        self.__nextNode = next
        self.__previousNode = previous 
        #define 

        if self.__nextNode is None:
            #if list is empty
            self.__nextNode = new_node
            new_node.__previousNode = self

        else:
            #else if list is not empty
            new_node.__nextNode = self.__nextNode
            self.__previousNode = new_node
            self.__nextNode = new_node
            new_node.__previousNode = self
            #set new nodes previous pointer to current node



    def insertBack(self, value):
        new_node = DoubleNode(value)
        current_node = self
        #current node + self
        while current_node.__nextNode is not None:
            current_node = current_node.__nextNode
        #traverse to last node
        current_node.__nextNode = new_node
        new_node.__previousNode = current_node

        

    def insertAfter(self, value_to_add, after_value) -> None:
        new_node = DoubleNode(value_to_add)
        #new node
        current_node = self
        while current_node is not None:
            if current_node == after_value:
                #traverse list to find node with after value
                new_node.__nextNode = current_node.__nextNode
                current_node.__previousNode = new_node
                new_node.__previousNode = current_node
                return True
            # return statement if inserted successfully
            current_node = current_node.__nextNode
            return False
        #if after_value is not found return statement

    
    def deleteFirstNode(self) -> None:
        # If we try to delete from an empty list, raise an exception
        if self.isEmpty():
            raise Exception("Error: List is empty")
        # Otherwise, grab the first node of the list
        first = self.getFirstNode()
        # Set the first node of the list to the second node
        self.setFirstNode(first.getNextNode())
        # Return the value of the deleted node
        return first.getValue()
    
    def deleteLastNode(self, ) -> None:
    
         # If we try to delete from an empty list, raise an exception
        if self.isEmpty():
            raise Exception("Error: List is empty")
        last = self.getLastNode()
        # Set the first node of the list to the second node
        self.setLastNode(last.getNextNode())
        # Return the value of the deleted node
        return last.getValue()
    
    def deleteValue(self, value) -> bool:
        # If we try to delete from an empty list, raise an exception
        if self.isEmpty():
            raise Exception("Error: Cannot delete from empty list")
        # Otherwise, traverse down the list starting with the first node
        previous = self.getFirstNode()
        while previous.getNextNode() != None:
            # Get the next node in the list
            next = previous.getNextNode() 
            # Check whether we want to delete the next node
            if value == next.getValue():
                # If so, change the next node of the previous node
                # to be the next node of the one we are deleting
                previous.setNextNode(next.getNextNode())
                # Return that the value was deleted
                return True
            # Update previous to be the next item in the list
            previous = next 
        # If the value was not found, raise an exception
        raise Exception("Error: Cannot find value {} in list".format(value))

    def forwardTraverse(self):
        current_node = self.__nextNode 
        while current_node is not None:
            #current node not none
            print(current_node.__value)
            current_node + current_node.__nextNode

    def reverseTraverse(self):
        current_node = self
        while current_node.__nextNode is not None:
            current_node = current_node.__nextNode
            #find last node
            while current_node is not None:
                print(current_node.__value)
                current_node = current_node.__previousNode
                #traverse backwards and print nodes values



    def __len__(yourDoublyLinkedList) -> int:
        # A counter starting at 0
        l = 0
        # Traverse down the doublylinkedlist starting with the first node
        node = yourDoublyLinkedList.getFirstNode() 
        # Stop when we reach the end of the list
        while node != None:
            # Increment the counter for each node we find
            l += 1
            # Update node to be the next node
            node = node.getNextNode()
        # Return the counter
        return l 
    
    def __str__(yourDoublyLinkedList) -> str:
        # Begin the string with the left bracket
        out = "["
        # Traverse down the list starting with the first node
        node = yourDoublyLinkedList.getFirstNode() 
        # Stop when we reach the end of the list
        while node != None:
            # Only add the arrow if there's more than one value in the list
            if len(out) > 1:
                out += " > "
            # Add the value of the current node to the string
            out += str(node)
            # Update node to be the next node
            node = node.getNextNode()
        # Add the closing bracket and return the string
        return out + "]"
    
if __name__ == "__main__":
    pass
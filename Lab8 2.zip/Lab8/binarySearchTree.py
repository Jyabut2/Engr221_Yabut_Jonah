"""
Jonah Yabut
May 5
Binary Search Tree
"""

class BinarySearchTree:
    """ DESCRIBE THE BST CLASS HERE
        *Nodes can have max of 2 children
         * Left child is less than parent
          * Right child is more than parent """

    def __init__(self):
        self.__root = None # The root Node of this BST

    def insert(self, insertKey, insertValue):
        """ Inserts the given key and value into the BST.
            Inputs:
                - insertKey: (any) The key to insert
                - insertValue: (any) The value to insert
            Returns: None
        """
        # Update the root to include the inserted node
        self.__root = self.__insertHelp(self.__root, insertKey, insertValue)
    
    def __insertHelp(self, node, insertKey, insertValue):
        """ A recursive helper method to insert a new node 
            with the given key and value into the BST.
            Inputs:
                - node: (Node) The root of the subtree to insert into
                - insertKey: (any) The key to insert
                - insertvalue: (any) The value to insert
            Returns: The node to insert """
        # Base case - Insert the node as a leaf in the appropriate location
        if node == None:
            return self.__Node(insertKey, insertValue)
        # Insert the key into the left subtree if it is less than the current key
        elif insertKey < node.key:
            node.left = self.__insertHelp(node.left, insertKey, insertValue)
        # Insert the key into the right subtree if it is greater than the current key
        elif insertKey > node.key:
            node.right = self.__insertHelp(node.right, insertKey, insertValue)
        # Return the node with the node inserted
        return node

    def isEmpty(self):
        """ If root is empty tree= empty"""
        if self.__root == None: 
            return True 
        else:
            return False 
        #return true if empty false if not
        pass
    
    def getRoot(self):
        """ Gets root from tree  """
        return self.__root
    #return root
        pass

    def search(self, goalKey):
        """ Searches for node with key then return """
        return self.__searchHelp(self.__root, goalKey)

    def __searchHelp(self, node, goalKey):
        """  A recursive method to help with the search() method, which
searches for a given key in the BST."""
        if node == None:
            return None
        #return none if key is not found
        if node.key == goalKey:
            return node
        if goalKey < node.key: 
            #if statement for goal key= less
            return self.__searchHelp(node.left, goalKey)
         #call down to left node
        if goalKey > node.key: 
            #if goal key = more
            return self.__searchHelp(node.right, goalKey)
        #call to right node
        pass

    def lookup(self, goal):
        """ Gets value of given key  """
        node = self.search(goal)
        #gets the node of the given key
        return  node.value
        #returns value
        pass

    def findSuccessor(self, subtreeRoot):
        """ Allows to find successor in the given root of Binart search tree """
        return self.__findSuccessorHelp(subtreeRoot)
    
    def __findSuccessorHelp(self, node):
        """ A recursive method to help with the findSuccessor() method,
which finds the smallest key in the tree. """
        if node.left == None:
            #if no smaller node then = smallest node
            return node
        if node.left !=None:
            return self._findSuccessorHelp(node.left)
        # if smaller node exists call left node
        pass
    
    def delete(self, deleteKey):
        """ Deletes given key and value in BST """
        if self.search(deleteKey):
            return self.__deleteHelp(self.__root, deleteKey)
        raise Exception("Key not in tree.")
    
    def __deleteHelp(self, node, deleteKey):
        """ A recursive method to help with the delete() method, which
deletes the node with the given key from the BST """
        #Deleting Leaf Node

        if node == None:
            return node
        elif deleteKey < node.key: 
            node.left = self.__deleteHelp(node.left, deleteKey) 
            #set left leaf node
            if self.isEmpty() == True: 
                #True if deleting one node
                self.__root = None 
            return node 
        #return node
        elif deleteKey > node.key:
            node.right = self.__deleteHelp(node.right, deleteKey)
             #set right leaf node
            if self.isEmpty() == True: 
                #true if deleting one node
                self.__root = None 
            return node 
        
        #Deletenode One Child

        if node.left != None or node.right != None:
            if node == None:
                return node
            if node.left != None:
                #left node case
                newchild = node.left
                if self.__root == node: 
            #if node is found in root 
                    self.__root = newchild
                     #set node 
                del node
                return newchild
            elif node.right != None:
                #right side case
                newchild = node.right
                if self.__root == node:
                    #if node is found in root
                    self.__root = newchild 
                   #set new node delete node
                del node
                return newchild
            
            #Deletenode two children
           
            if node.left != None and node.right != None:
             newnode = self.findSuccessor(node.right)
            self.delete(self.findSuccessor(node.right).key)
            #deletes leaf to replace node that will delete
            leftchild = node.left
            rightchild = node.right
            #left and right child 
            newnode.left = leftchild
            newnode.right = rightchild
            #moves children to new node

            if self.__root == node: 
                self.__root = newnode 
                #changes root to new node with children

            return newnode

        pass

    def traverse(self) -> None:
        """ Inserts key + value into BST """
        self.__traverseHelp(self.__root)

    def __traverseHelp(self, node) -> None:
        """ A recursive method to help with the traverse() method, which
visits each node in the tree, in ascending order (i.e., using depth-first search) """
#Visits nodes in tree to find smallest value
        list =[]
        if node != None: 
            self.__traverseHelp(node.left)
            #calls upon left node <
            print(node) 
            #prints node smallest value
            self.__traverseHelp(node.right) 

        pass

    

    def __str__(self) -> str:
        """ Represent the tree as a string. Formats as 
            {(rootkey, rootval), {leftsubtree}, {rightsubtree}} """
        return self.__strHelp("", self.__root)
    
    def __strHelp(self, return_string, node) -> str:
        """ A recursive helper method to format the tree as a string. 
            Input: 
                - return_string: (string) Accumulates the final string to output
                - node: (Node) The current node to format
            Returns: A formatted string for this node. """
        # Base case - Represent an empty branch as "None"
        if node == None:
            return "None"
        # Recursively build the string to return
        # Note, this is equivalent to
        #   return "{" + node + ", " + \
        #                self.strHelp(return_string, node.left) + ", " + \
        #                self.strHelp(return_string, node.right) + "}"
        return "{{{}, {}, {}}}".format(node, 
                                       self.__strHelp(return_string, node.left), 
                                       self.__strHelp(return_string, node.right))
            

    ##############
    # NODE CLASS #
    ##############

    class __Node:
        """ Implementation of a node in a BST. Note that it is 
            private, so it cannot be accessed outside of a BST """

        def __init__(self, key, value, left=None, right=None):
            self.key = key         # The key of the root node of this tree
            self.value = value     # The value held by the root node of this tree
            self.left = left       # Points to the root of the left subtree
            self.right = right     # Points to the root of the right subtree

        def __str__(self):
            """ Represent the node as a string.
                Formats as "{key, value}" """
            return "({}, {})".format(self.key, self.value)
        
if __name__ == "__main__":
    bst = BinarySearchTree()
    bst.insert(5, "five")
    bst.insert(8, "eight")
    bst.insert(3, "three")
    bst.insert(1, "one")


    bst.delete(5)
    print(bst)

    pass
import pytest

from ..box import Box

# Write your tests here
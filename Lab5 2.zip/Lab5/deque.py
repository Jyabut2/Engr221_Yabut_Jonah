"""
Jonah Yabut
Deque

"""

from .doublyLinkedList import DoublyLinkedList

class Deque():
    def __init__(self):
        self.__values = DoublyLinkedList()
        # intitialize self, self values= doubly

    def isEmpty(self):
        return self.__values.isEmpty()
    #check whether or not list is empty 
    #boolean 
    
    def __len__(self):
        return len(self.__values)
    #checks length of  of values in doubly linked list
    #traverses down the list starting with first node
    
    def __str__(self):
        return str(self.__values)
    #string that represents the list where n is the number of nodes in the list
#traverses down the same way as length

    def peekLeft(self):
        return self.__values.first()
    
#did not use
    def peekRight(self):
        return self.__values.getLastNode().getValue()
#did not use
    def insertLeft(self, value):
        self.__values.insertFront(value)
        #did not use
      
    def insertRight(self, value): 
        self.__values.insertBack(value)
        #did not use
 
    def removeLeft(self): 
        return self.__values.deleteFirstNode()
# did not use
    def removeRight(self):
        return self.__values.deleteLastNode()
    #did not use
if __name__ == "__main__":
    pass
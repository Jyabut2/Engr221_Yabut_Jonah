"""
Jonah Yabut
MazeSolver
"""
from SearchStructures import Stack, Queue
from Maze import Maze

class MazeSolver:
    # Constructor
    # Inputs:
    #   maze: The maze to solve (Maze)
    #   searchStructure: The search structure class to use (Stack or Queue)
    def __init__(self, maze, searchStructure):
        self.maze = maze             # The maze to solve
        self.ss = searchStructure()  # Initialize a searchStructure object

    def tileIsVisitable(self, row:int, col:int) -> bool:
        # ~~~~~~~~
        # Write your tileIsVisitable() implementation here
        # ~~~~~~~~
        self.maze.num_cols
        if col > self.maze.num_cols -1:
            return False
        if row > self.maze.num_rows -1:
            return False
        if row < 0:
            return False
        if col < 0:
            return False
        Wall = self.maze.contents[row][col].isWall()
        if Wall: 
            return False
        Visited = self.maze.contents[row][col].visited()
        #is visible
        if Visited:
            #return statment if tile is visited 
            return False
        return True


    def solve(self):
        # ~~~~~~~~
        # Write your solve() implementation here
        # ~~~~~~~~
        self.ss.add(self.maze.start)
        while not self.ss.isEmpty():
                    #make sure is not empty
                    current = self.ss.remove()
        if current == self.maze.goal:
             #if statement current is visited 
             for d_row, d_col in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    next_row, next_col = current.row + d_row, current.col + d_col
        if self.tileIsVisitable(next_row, next_col):
                    next_tile = self.maze.contents[next_row][next_col]
                    self.ss.add(next_tile) 
     # Add any other helper functions you might want here

    def getPath(self):
        # ~~~~~~~~
        # Write your getPath() implementation here
        # ~~~~~~~~
        path = []
        current = self.maze.goal
        while current != self.maze.start:
            path.append(current)
            current = current.prev  
            # To move to previous tile in path
        path.append(self.maze.start)
        return path[::-1]  
    #return 

    # Print the maze with the path of the found solution
    # from Start to Goal. If there is no solution, just
    # print the original maze.
    def printSolution(self):
        # Get the solution for the maze from the maze itself
        solution = self.getPath()
        # A list of strings representing the maze
        output_string = self.maze.makeMazeBase()
        # For all of the tiles that are part of the path, 
        # mark it with a *
        for tile in solution:
            output_string[tile.getRow()][tile.getCol()] = '*'
        # Mark the start and goal tiles
        output_string[self.maze.start.getRow()][self.maze.start.getCol()] = 'S'
        output_string[self.maze.goal.getRow()][self.maze.goal.getCol()] = 'E'
        

        # Print the output string
        for row in output_string:
            print(row)

   

if __name__ == "__main__":
    # The maze to solve
    maze = Maze(["____",
                 "_##E",
                 "_S#_",
                 "____"])
    # Initialize the MazeSolver to be solved with a Stack
    solver = MazeSolver(maze, Stack)
    # Solve the maze
    solver.solve()
    # Print the solution found
    solver.printSolution()
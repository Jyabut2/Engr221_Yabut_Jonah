import pytest

from ..myHashMap import MyHashMap

# Write your tests here
@pytest.fixture 
def nonemptyList():
    newmap = MyHashMap()
    newmap.put(0,1)
    newmap.put(1,2)
    newmap.put(2,5)
    return newmap

@pytest.mark.removevalue
def test_removevalue_val(nonemptyList):
    #delete value from the list
    val = nonemptyList.remove(0)
    assert val == None
    #check and confirm value = none

@pytest.mark.size
def test_size(nonemptyList):
    #size check
    val = nonemptyList.size
    assert val == 2
    #check if value 2 is returned 

@pytest.mark.isEmpty
def test_isempty_false(nonemptyList):
    assert not nonemptyList.isEmpty()
    #returns false 

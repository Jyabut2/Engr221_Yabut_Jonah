"""
Jonah Yabut
Search Structures
"""

# Implementation of a Stack
class Stack():
    def __init__(self):
        self.__items = []

    # Returns True if the Stack is empty, or False if it is not empty
    def isEmpty(self):
        return self.items == [] 
    #return statment if structure is empty or not

    # For a Stack, this should "push" item to the top of the Stack
    def add(self, item):
        self.items.append(item)

    # For a Stack, this should "pop" an item from the Stack
    # and return it
    def remove(self):
        def remove(self):
         if not self.isEmpty():
            return self.items.pop()
         #pop item from top of stack
        return None
    
# Implementation of a Queue
class Queue():
    def __init__(self):
        self.__items = []

    # Returns True if the Queue is empty, or False if it is not empty
    def isEmpty(self):
        return self == []
    #same as defisEmpty in class stack

    # For a Queue, this should "enqueue" item to the end of the Queue
    def add(self, item):
        self.items.append(item)
        #same as defadd in class stack

    # For a Queue, this should "dequeue" an item from the Queue
    # and return it
    def remove(self):
        if not self.isEmpty():
            return self.items.pop(0)
        #same as def remove in class stack
    
    
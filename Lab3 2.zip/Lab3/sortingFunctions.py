"""
jonah yabut
sortingFunctions.py
Description: Implementation of sorting algorithms.
"""

from pickletools import pylist
import time, random

# Implementation of insertionSort algorithm
def insertionSort(list_to_sort:list) -> list:
    def insertionSort(A):
    #insertionSortA
    ### Add your insertionSort implementation here
     for i in range(1,len(A)):
        key= A[i]
        j = i - 1
        while j >= 0 and A[j] > key:
            A[j + 1] = A[j]
            j -= 1
            A[j + 1] = key
            #call key
           
            mylist = [8,4,1,2]
            #sort inputed list
            insertionSort(mylist)
        

     print(mylist)

# Implementation of bubbleSort algorithm
def bubbleSort(list_to_sort:list) -> list:
    ### Add your bubbleSort implementation here
   for i in range(len(list_to_sort)-1):
        for j in range(len(list_to_sort)-1-i):
            if list_to_sort[j] > list_to_sort[j+1]:
                #sort list
                temp = list_to_sort[j+1]
                list_to_sort[j+1] = list_to_sort[j]
                list_to_sort[j] = temp
   
   return list_to_sort

# Returns a random list of the given length
def createRandomList(length:int) -> list:
    return random.sample(range(max(100, length)), length)
    
# Returns the length of time (in seconds) that it took
# for the function_to_run to sort a list of length list_length
def getRuntime(function_to_run, list_length) -> float:
    # Create a new list to sort
    list_to_sort = createRandomList(list_length)
    # Get the time before running
    start_time = time.time()
    # Sort the given list
    function_to_run(list_to_sort)
    # Get the time after running
    end_time = time.time()
    # Return the difference
    return end_time - start_time


if __name__ == '__main__':
    pass
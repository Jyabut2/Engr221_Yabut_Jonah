import pytest

from ..box import Box

# Write your tests here
@pytest.fixture 
def nonemptyBox():
    newmap = Box()
    newmap.populateBox()
    return newmap


@pytest.mark.findEntryByNickname
def test_findEntryByNickname(nonemptyBox):
    find = nonemptyBox.findEntryByNickname("Rose")
    assert find == ["Rose", "Tailow"]
    #return entry after finding by nickname

@pytest.mark.find
def test_find(nonemptyBox):
    find = nonemptyBox.find("Rose", "Tailow")
    assert find == ["Rose", "Tailow"] 
    #returns entry found
    
@pytest.mark.removeByNickname
def test_removeByNickname(nonemptyBox):
    removed = nonemptyBox.removeByNickname("Rose")
    #return true after removal
    assert removed == True 

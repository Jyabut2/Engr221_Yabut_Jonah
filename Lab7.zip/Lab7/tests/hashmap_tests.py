import pytest

from ..myHashMap import MyHashMap

# Write your tests here